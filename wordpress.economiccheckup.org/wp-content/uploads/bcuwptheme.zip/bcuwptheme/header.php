<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="language" content="en-US" />
	<meta name="lang" content="en" />
	<meta name="description" content="Here is the description of your project." />
	<meta name="keywords" content="" />
	<meta name="Copyright" content="Copyright NCOA 2011" />
	<!-- Speaking of Google, don't forget to set your site up: http://google.com/webmasters -->	
	<meta name="google-site-verification" content="" />

	<!-- This is the traditional favicon.
		 - size: 16x16 or 32x32
		 - transparency is OK
		 - see wikipedia for info on broswer support: http://mky.be/favicon/ -->	
	<link rel="shortcut icon" href="wp-content/themes/bcuwptheme/images/favicon.png"/>
	<!-- The is the icon for iOS's Web Clip.
		 - size: 57x57 for older iPhones, 72x72 for iPads, 114x114 for iPhone4's retina display (IMHO, just go ahead and use the biggest one)
		 - To prevent iOS from applying its styles to the icon name it thusly: apple-touch-icon-precomposed.png
		 - Transparency is not recommended (iOS will put a black BG behind the icon) -->
	<link rel="apple-touch-icon" href="wp-content/themes/bcuwptheme/images/custom_icon.png"/>
    <link rel="stylesheet" type="text/css" href="wp-content/themes/bcuwptheme/css/resets.css">
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />    
	<link rel="stylesheet" media="print" href="wp-content/themes/bcuwptheme/css/print.css" />
	<!--[if IE 6]><link rel="stylesheet" type="text/css" href="wp-content/themes/bcuwptheme/css/ie6.css" /><![endif]-->
	<!--[if IE 7]><link rel="stylesheet" type="text/css" href="wp-content/themes/bcuwptheme/css/ie7.css" /><![endif]-->
	<!--[if IE 8]><link rel="stylesheet" type="text/css" href="wp-content/themes/bcuwptheme/css/ie8.css" /><![endif]-->
	<script src="wp-content/themes/bcuwptheme/js/libs/modernizr-2.0.6.min.js"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="wp-content/themes/bcuwptheme/js/libs/jquery-1.6.2.min.js"><\/script>')</script>
	<script>Modernizr.input.placeholder || document.write('<script src="wp-content/themes/bcuwptheme/js/libs/jquery.f5.js"><\/script>')</script>
    <script src="js/scripts.js"></script>
	<link href="http://fonts.googleapis.com/css?family=PT+Sans&v1" rel="stylesheet" type="text/css">
	<title>Benefitscheckup.org</title>

<?php
/* 
 * 	Add this to support sites with sites with threaded comments enabled.
 */
	if ( is_singular() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );

	//wp_head();
	
	wp_get_archives('type=monthly&format=link');
?>
</head>

<body class="js">

<div id="wrapper">
	<div id="ada508">  
		<strong>Shortcut Navigation:</strong> 
		<ul> 
			<li><a href="#content" accesskey="p" title="Skip to page content">Page Content</a></li> 
			<li><a href="#topNav" accesskey="n" title="Skip to main navigation menu">Site Navigation</a></li>

			<li><a href="#search" accesskey="s" title="Skip to search">Search</a></li> 
			<li><a href="#footer" accesskey="f" title="Skip to footer (ctrl/alt + f)">Footer</a></li> 
		</ul> 
	</div> 
<!-- #ada508 shortcuts --> 
	
    <div id="header">
   
    	<h1><a href=" http://www.ncoa.org"><img src="wp-content/themes/bcuwptheme/images/logos/ncoa_top.png" alt="NCOA logo" id="topbar" /></a></h1>
       	<a href="homepage.html" class="block"><img src="wp-content/themes/bcuwptheme/images/logos/bcu.png" alt="Benefits Checkup logo" /></a>
       	<p>We have helped <strong>2,917,998</strong> people find over <strong>$10.3 billion</strong> worth of benefits </p>
       
        <div id="sponsors">
        	<h2>Special thanks to:</h2>
        	<img src="wp-content/themes/bcuwpthemeimages/logos/walmart.gif" alt="Walmart logo" />
        </div><!-- sponsors --> 

    </div><!--end header -->
	
    
    <div id="main-nav">
    	<?php 
    		wp_nav_menu( 
    			array( 
    					'sort_column' => 'menu_order', 
    					'menu_class' => 'nav', 
    					'theme_location' => 'primary-menu' ) ); 
    	?> 
	
    </div><!--end main nav --> 
	
	<div id="breadcrumbs">
		<p>
			<?php
				if(function_exists('bcn_display'))
				{
				    bcn_display();
				}
			?>
		</p>
	</div><!--end breadcrumbs --> 


  