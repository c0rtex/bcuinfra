</div><!--end content -->

   
   </div><!--end page -->
    <div id="footer">
		<div class="sub-wrapper">	
					<div id="bcu" class="sites">
					<h2>BenefitsCheckUp site:</h2>
						<ul>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Site Map</a></li>

							<li><a href="#">Privacy Policy</a></li>
							<li><a href="#">Terms of Use</a></li>
							<li><a href="#">Feedback</a></li>
							<li><a href="#">Organizational Users</a></li>
						</ul>
					</div>
                    <div id="other" class="sites">
                    <h2>Other NCOA Sites:</h2>
						<ul>
							<li><a href="#">BenefitsCheckUp</a></li>
							<li><a href="#">Better Choice, Better Health</a></li>

							<li><a href="#">Home Equity Advisor</a></li>
							<li><a href="#">One Away Campaign for Elder Economic Security</a></li>
							<li><a href="#">Center for Healthy Aging</a></li>
							<li><a href="#">Center for Benefits Outreach and Enrollment</a></li>
						</ul>
                        </div>
					<div id="publicpolicy" class="sites">
					<h2>Public Policy:</h2>

						<ul>
							<li><a href="#">Our Positions</a></li>		<li><a href="#">Federal Funding for Seniors Program</a></li>
							<li><a href="#">Older Americans Act</a></li>
							<li><a href="#">Long-Term Services &amp; Supports</a></li>
							<li><a href="#">Health Care Reform</a></li>

                            <li><a href="#">Advocacy Toolkit</a></li>
						</ul>
					</div>
                    <div id="pressroom" class="sites">
					<h2>Press Room:</h2>
						<ul>
							<li><a href="#">Press Releases</a></li>
                            <li><a href="#">News</a></li>

                            <li><a href="#">NCOA In The News</a></li>
                            <li><a href="#">Fact Sheets</a></li>
                            <li><a href="#">Media Contacts</a></li>
						</ul>
					</div>
                   <div id="about" class="sites">
					<h2>About NCOA:</h2>
						<ul>

							<li><a href="#">Overview</a></li>
                            <li><a href="#">Locations</a></li>
                            <li><a href="#">Leadership</a></li>
                            <li><a href="#">Funders</a></li>
                            <li><a href="#">Annual Report</a></li>
                            <li><a href="#">Careers</a></li>
                            <li><a href="#">Awards</a></li>
                            <li><a href="#">Conference</a></li>
						</ul>
					</div>
                   <div id="f-stay-connected" class="sites">
					<h2>Stay Connected:</h2>
						<ul>
							<li class="fb"><a href="#">NCOA on Facebook</a></li>
                            <li class="twitter"><a href="#">NCOA on Twitter</a></li>
							<li class="cr"><a href="#">Crossroads Community for Professionals in Aging</a></li>
							<li class="fb"><a href="#"><em>One Away</em> on Facebook</a></li>
                            <li class="rss"><a href="#">RSS</a></li>						
						</ul>
                	</div>
                </div>
			<div id="footer-primary">
				<p><a href="#"><img src="wp-content/themes/bcuwptheme/images/logos/ncoa_large.png" alt="" /></a></p>		
				<p>1901 L Street, NW&nbsp;&nbsp;&nbsp;4th Floor&nbsp;&nbsp;&nbsp;Washington, D.C. 20036 &nbsp;&nbsp;| &nbsp;&nbsp;202.479.1200</p>
			</div> <!-- end footer-primary -->

		</div> <!-- end sub-wrapper -->
	</div><!-- #footer -->



</div> <!--end wrapper -->

<script type="text/javascript">
$('form').ready(function(){
    $('form').f5();
});
</script>
</body>
</html>
